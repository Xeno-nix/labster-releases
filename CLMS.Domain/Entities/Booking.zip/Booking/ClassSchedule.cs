﻿using CLMS.Domain.Common;
using CLMS.Domain.Entities.Users;
namespace CLMS.Domain.Entities.Booking;
public class ClassSchedule : AuditableEntity
{
    public int Id { get; private set; }
    public int CourseId { get; set; }
    public Course? Course { get; set; }
    public int InstructorId { get; set; }
    public User? Instructor { get; set; }
    public int LaboratoryId { get; set; }
    public Laboratory? Laboratory { get; set; }
    public int AcademicTermId { get; set; }
    public AcademicTerm? AcademicTerm { get; set; }
    public DayOfWeek DayOfWeek { get; set; }
    public TimeOnly TimeStart { get; set; }
    public TimeOnly TimeEnd { get; set; }


}
