﻿namespace CLMS.Domain.Entities.Booking;
public class Laboratory
{
    public int Id { get;private set; }
    public string Name { get; set; }

    public Laboratory(int id, string name)
    {
        Id = id;
        Name = name;
    }
}
